import React, { useState } from 'react';
import { 
  CreditCard, 
  Send, 
  Check, 
  Plus, 
  Search, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCw,
  Wallet
} from 'lucide-react';
import { MonthlyFee, Student, FeeStatus } from '../types';
import { formatCurrency, generateWhatsAppUrl, getCurrentMonthYear, getTodayDateBR, generateUUID } from '../utils/formatters';
import { EmptyState } from '../components/EmptyState';

interface FeesViewProps {
  fees: MonthlyFee[];
  students: Student[];
  onRegisterPayment: (fee: MonthlyFee, amountPaid: number, method: 'PIX' | 'DINHEIRO' | 'CARTAO' | 'OUTRO', notes?: string) => void;
  onGenerateMonthFees: () => void;
}

export const FeesView: React.FC<FeesViewProps> = ({
  fees,
  students,
  onRegisterPayment,
  onGenerateMonthFees,
}) => {
  const [filter, setFilter] = useState<'TODOS' | 'ATRASADO' | 'PENDENTE' | 'PAGO'>('TODOS');
  const [search, setSearch] = useState('');
  const [payingFee, setPayingFee] = useState<MonthlyFee | null>(null);

  // Payment modal state
  const [amountPaid, setAmountPaid] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'PIX' | 'DINHEIRO' | 'CARTAO' | 'OUTRO'>('PIX');
  const [paymentNotes, setPaymentNotes] = useState('');

  const currentMonthYear = getCurrentMonthYear();

  const filteredFees = fees.filter((f) => {
    const matchesFilter = filter === 'TODOS' || f.status === filter;
    const matchesSearch =
      f.studentName.toLowerCase().includes(search.toLowerCase()) ||
      f.monthYear.includes(search);
    return matchesFilter && matchesSearch;
  });

  const handleOpenPayment = (fee: MonthlyFee) => {
    setPayingFee(fee);
    setAmountPaid(fee.amount.toString());
    setPaymentMethod('PIX');
    setPaymentNotes('');
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingFee) return;

    const paidVal = parseFloat(amountPaid) || payingFee.amount;
    onRegisterPayment(payingFee, paidVal, paymentMethod, paymentNotes);
    setPayingFee(null);
  };

  const totalOverdue = fees
    .filter((f) => f.status === 'ATRASADO')
    .reduce((acc, f) => acc + f.amount, 0);

  return (
    <div className="space-y-4 pb-20">
      {/* Header bar */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Mensalidades</h2>
          <p className="text-xs text-[#9CA3AF]">Controle de cobranças e pagamentos</p>
        </div>

        <button
          onClick={onGenerateMonthFees}
          className="min-h-[44px] px-3.5 rounded-xl bg-[#131212] border border-[#272424] text-white font-bold text-xs flex items-center gap-1.5 hover:border-[#FF4A0F] active:scale-95 transition-all"
          title="Gerar mensalidades do mês atual para todos os alunos ativos"
        >
          <RefreshCw className="w-3.5 h-3.5 text-[#FF4A0F]" />
          <span>Gerar ({currentMonthYear})</span>
        </button>
      </div>

      {/* Overdue Total Banner */}
      {totalOverdue > 0 && (
        <div className="p-3.5 rounded-2xl bg-[#EF4444]/15 border border-[#EF4444]/40 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-[#EF4444] shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-white">Total em Atraso</h4>
              <p className="text-[11px] text-[#D1D5DB]">
                {fees.filter((f) => f.status === 'ATRASADO').length} mensalidades pendentes
              </p>
            </div>
          </div>
          <span className="text-base font-black text-[#EF4444]">{formatCurrency(totalOverdue)}</span>
        </div>
      )}

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por aluno ou mês (ex: 10/2026)..."
          className="w-full min-h-[44px] pl-10 pr-4 rounded-xl bg-[#131212] border border-[#272424] text-white text-xs placeholder:text-[#6B7280] focus:border-[#FF4A0F] focus:outline-none"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {[
          { key: 'TODOS' as const, label: `Todas (${fees.length})` },
          { key: 'ATRASADO' as const, label: `Atrasadas (${fees.filter((f) => f.status === 'ATRASADO').length})` },
          { key: 'PENDENTE' as const, label: `A Vencer (${fees.filter((f) => f.status === 'PENDENTE').length})` },
          { key: 'PAGO' as const, label: `Pagas (${fees.filter((f) => f.status === 'PAGO').length})` },
        ].map((tab) => {
          const isSelected = filter === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`min-h-[36px] px-3.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-[#FF4A0F] text-white'
                  : 'bg-[#131212] text-[#9CA3AF] border border-[#272424] hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Fees List */}
      {filteredFees.length === 0 ? (
        <EmptyState
          icon={CreditCard}
          title={fees.length === 0 ? 'Nenhuma mensalidade lançada' : 'Nenhuma mensalidade neste filtro'}
          description={
            fees.length === 0
              ? 'Toque em "Gerar" acima para emitir as mensalidades do mês atual para todos os alunos ativos.'
              : 'Nenhum resultado corresponde ao filtro de busca selecionado.'
          }
          actionLabel={fees.length === 0 ? 'Gerar Mensalidades do Mês' : undefined}
          onAction={fees.length === 0 ? onGenerateMonthFees : undefined}
        />
      ) : (
        <div className="space-y-2.5">
          {filteredFees.map((fee) => {
            const student = students.find((s) => s.id === fee.studentId);
            const isPaid = fee.status === 'PAGO';
            const isOverdue = fee.status === 'ATRASADO';

            return (
              <div
                key={fee.id}
                className={`p-3.5 rounded-2xl bg-[#131212] border transition-all shadow-md ${
                  isOverdue
                    ? 'border-[#EF4444]/40'
                    : isPaid
                    ? 'border-[#10B981]/30'
                    : 'border-[#272424]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-white">{fee.studentName}</h3>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          isPaid
                            ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30'
                            : isOverdue
                            ? 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30'
                            : 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30'
                        }`}
                      >
                        {fee.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#9CA3AF] mt-0.5">
                      Referência: {fee.monthYear} • Vencimento: {fee.dueDate}
                    </p>

                    <p className="text-sm font-black text-white mt-1">
                      {formatCurrency(fee.amount)}
                      {isPaid && fee.paymentMethod && (
                        <span className="text-xs text-[#10B981] font-semibold ml-2">
                          (Pago via {fee.paymentMethod} em {fee.paidDate})
                        </span>
                      )}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Botão Cobrar no WhatsApp (wa.me) */}
                    {student?.phone && (
                      <a
                        href={generateWhatsAppUrl(
                          student.phone,
                          isPaid
                            ? `Olá ${student.name}! Confirmamos o recebimento da sua mensalidade referente a ${fee.monthYear} no valor de ${formatCurrency(fee.amountPaid)}. Agradecemos a pontualidade na Academia UBF Team! Oss!`
                            : `Olá ${student.name}, tudo bem? Mensagem da Academia UBF Team Parque Indiano (Mestre Uarlei Silva): sua mensalidade de ${formatCurrency(fee.amount)} com vencimento em ${fee.dueDate} está pendente. Para sua comodidade, chave Pix: 11988887777 (UBF Team). Qualquer dúvida estamos à disposição! Oss!`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-9 h-9 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-center text-[#10B981] active:scale-95"
                        title="Cobrar pelo WhatsApp"
                      >
                        <Send className="w-4 h-4" />
                      </a>
                    )}

                    {/* Botão Registrar Pagamento */}
                    {!isPaid ? (
                      <button
                        onClick={() => handleOpenPayment(fee)}
                        className="min-h-[38px] px-3.5 rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center gap-1.5 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Receber</span>
                      </button>
                    ) : (
                      <span className="w-9 h-9 rounded-xl bg-[#10B981]/20 flex items-center justify-center text-[#10B981]">
                        <CheckCircle2 className="w-5 h-5" />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Registrar Pagamento */}
      {payingFee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-[#131212] border border-[#272424] rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#272424] mb-4">
              <div>
                <h3 className="text-base font-bold text-white">Registrar Pagamento</h3>
                <p className="text-xs text-[#FF4A0F]">
                  {payingFee.studentName} • Ref: {payingFee.monthYear}
                </p>
              </div>
              <button onClick={() => setPayingFee(null)} className="text-[#9CA3AF] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPayment} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">
                  Valor Efetivamente Recebido (R$) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#050505] border border-[#272424] text-white text-base font-bold focus:border-[#FF4A0F] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1.5">
                  Forma de Pagamento
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['PIX', 'DINHEIRO', 'CARTAO', 'OUTRO'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`min-h-[40px] px-3 rounded-lg text-xs font-bold transition-all ${
                        paymentMethod === method
                          ? 'bg-[#FF4A0F] text-white shadow-md'
                          : 'bg-[#050505] text-[#9CA3AF] border border-[#272424]'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Observações</label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="Comprovante Pix ou desconto acordado..."
                  className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                />
              </div>

              <p className="text-[11px] text-[#6B7280] leading-relaxed">
                Este valor entrará automaticamente no Caixa da academia como Receita do mês sem duplicar.
              </p>

              <button
                type="submit"
                className="w-full min-h-[46px] rounded-xl bg-[#10B981] text-black font-black text-xs flex items-center justify-center gap-2 hover:bg-[#0ea372] active:scale-95 shadow-md shadow-[#10B981]/20 mt-4"
              >
                <Check className="w-4 h-4" />
                <span>Confirmar Recebimento</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
