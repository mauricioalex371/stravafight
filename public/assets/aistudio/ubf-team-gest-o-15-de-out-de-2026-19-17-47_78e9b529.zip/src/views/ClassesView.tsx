import React, { useState } from 'react';
import { 
  Calendar, 
  Plus, 
  Check, 
  X, 
  UserCheck, 
  UserX, 
  Clock, 
  Users, 
  Trash2, 
  UserPlus, 
  Send,
  History
} from 'lucide-react';
import { ClassEntity, Student, AttendanceRecord, TrialStudent } from '../types';
import { generateUUID, getTodayDateBR, generateWhatsAppUrl } from '../utils/formatters';
import { EmptyState } from '../components/EmptyState';

interface ClassesViewProps {
  classes: ClassEntity[];
  students: Student[];
  attendance: AttendanceRecord[];
  trials: TrialStudent[];
  masterName: string;
  onSaveClass: (c: ClassEntity) => void;
  onDeleteClass: (id: string) => void;
  onRecordAttendance: (classId: string, studentId: string, date: string, status: 'PRESENTE' | 'FALTA') => void;
  onSaveTrial: (t: TrialStudent) => void;
  onConvertTrialToStudent: (t: TrialStudent) => void;
  onDeleteTrial: (id: string) => void;
}

export const ClassesView: React.FC<ClassesViewProps> = ({
  classes,
  students,
  attendance,
  trials,
  masterName,
  onSaveClass,
  onDeleteClass,
  onRecordAttendance,
  onSaveTrial,
  onConvertTrialToStudent,
  onDeleteTrial,
}) => {
  const [subTab, setSubTab] = useState<'turmas' | 'chamada' | 'experimentais'>('turmas');
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [attendanceDate, setAttendanceDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Modal states
  const [isClassModalOpen, setIsClassModalOpen] = useState(false);
  const [isTrialModalOpen, setIsTrialModalOpen] = useState(false);
  const [studentHistoryModal, setStudentHistoryModal] = useState<Student | null>(null);

  // New Class Form
  const [name, setName] = useState('');
  const [modality, setModality] = useState('Jiu-Jitsu');
  const [level, setLevel] = useState('Todos os Níveis');
  const [instructor, setInstructor] = useState(masterName);
  const [days, setDays] = useState<string[]>(['Seg', 'Qua', 'Sex']);
  const [startTime, setStartTime] = useState('19:30');
  const [endTime, setEndTime] = useState('21:00');
  const [maxCapacity, setMaxCapacity] = useState('30');

  // New Trial Form
  const [trialName, setTrialName] = useState('');
  const [trialPhone, setTrialPhone] = useState('');
  const [trialModality, setTrialModality] = useState('Jiu-Jitsu');
  const [trialDate, setTrialDate] = useState(getTodayDateBR());
  const [trialNotes, setTrialNotes] = useState('');

  const toggleDay = (day: string) => {
    if (days.includes(day)) {
      setDays(days.filter((d) => d !== day));
    } else {
      setDays([...days, day]);
    }
  };

  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newClass: ClassEntity = {
      id: generateUUID(),
      name: name.trim(),
      modality,
      level,
      instructor: instructor.trim() || masterName,
      days: days.length > 0 ? days : ['Seg', 'Qua', 'Sex'],
      startTime,
      endTime,
      maxCapacity: parseInt(maxCapacity, 10) || 25,
    };

    onSaveClass(newClass);
    if (!selectedClassId) setSelectedClassId(newClass.id);
    setIsClassModalOpen(false);
  };

  const handleCreateTrial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialName.trim()) return;

    const newTrial: TrialStudent = {
      id: generateUUID(),
      name: trialName.trim(),
      phone: trialPhone.trim(),
      modality: trialModality,
      scheduledDate: trialDate.trim(),
      status: 'AGENDADA',
      notes: trialNotes.trim(),
      createdAt: Date.now(),
    };

    onSaveTrial(newTrial);
    setIsTrialModalOpen(false);
  };

  const activeClass = classes.find((c) => c.id === selectedClassId) || classes[0];

  // Students eligible for this class (active and matching modality or linked)
  const classStudents = students.filter(
    (s) => s.status === 'ATIVO' && (s.classId === activeClass?.id || s.modality === activeClass?.modality)
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Sub tabs */}
      <div className="flex bg-[#131212] p-1 rounded-xl border border-[#272424]">
        <button
          onClick={() => setSubTab('turmas')}
          className={`flex-1 min-h-[38px] rounded-lg text-xs font-bold transition-all ${
            subTab === 'turmas' ? 'bg-[#FF4A0F] text-white shadow-md' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Turmas ({classes.length})
        </button>
        <button
          onClick={() => setSubTab('chamada')}
          className={`flex-1 min-h-[38px] rounded-lg text-xs font-bold transition-all ${
            subTab === 'chamada' ? 'bg-[#FF4A0F] text-white shadow-md' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Chamada / Presença
        </button>
        <button
          onClick={() => setSubTab('experimentais')}
          className={`flex-1 min-h-[38px] rounded-lg text-xs font-bold transition-all ${
            subTab === 'experimentais' ? 'bg-[#FF4A0F] text-white shadow-md' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Experimentais ({trials.filter((t) => t.status === 'AGENDADA').length})
        </button>
      </div>

      {/* 1. GRADE DE TURMAS */}
      {subTab === 'turmas' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">Grade de Aulas</h3>
            <button
              onClick={() => {
                setName('');
                setIsClassModalOpen(true);
              }}
              className="min-h-[44px] px-4 rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center gap-1.5 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20"
            >
              <Plus className="w-4 h-4" />
              <span>Nova Turma</span>
            </button>
          </div>

          {classes.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="Nenhuma turma cadastrada"
              description="Cadastre as turmas e horários de treino da sua academia."
              actionLabel="Criar Primeira Turma"
              onAction={() => setIsClassModalOpen(true)}
            />
          ) : (
            <div className="space-y-3">
              {classes.map((cls) => {
                const enrolledCount = students.filter(
                  (s) => s.status === 'ATIVO' && (s.classId === cls.id || s.modality === cls.modality)
                ).length;

                return (
                  <div
                    key={cls.id}
                    className="p-4 rounded-2xl bg-[#131212] border border-[#272424] hover:border-[#FF4A0F]/40 transition-all shadow-md"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-bold text-white">{cls.name}</h4>
                          <span className="text-[10px] font-bold text-[#FF4A0F] bg-[#FF4A0F]/10 px-2 py-0.5 rounded-full border border-[#FF4A0F]/30">
                            {cls.modality}
                          </span>
                        </div>
                        <p className="text-xs text-[#9CA3AF] mt-1">
                          Professor: {cls.instructor} • Nível: {cls.level}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          if (confirm(`Deseja excluir a turma ${cls.name}?`)) {
                            onDeleteClass(cls.id);
                          }
                        }}
                        className="text-[#6B7280] hover:text-[#EF4444] p-1.5"
                        title="Excluir Turma"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 mt-4 pt-3 border-t border-[#272424] text-xs">
                      <div className="flex items-center gap-1.5 text-white font-semibold">
                        <Clock className="w-4 h-4 text-[#FF4A0F]" />
                        <span>
                          {cls.days.join(', ')} • {cls.startTime} às {cls.endTime}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedClassId(cls.id);
                          setSubTab('chamada');
                        }}
                        className="min-h-[36px] px-3 rounded-lg bg-[#FF4A0F]/15 border border-[#FF4A0F]/40 text-[#FF4A0F] font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Fazer Chamada ({enrolledCount})</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 2. CHAMADA / PRESENÇA RÁPIDA (1 TOQUE) */}
      {subTab === 'chamada' && (
        <div className="space-y-4">
          {classes.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="Crie uma turma primeiro"
              description="Você precisa cadastrar ao menos uma turma para registrar a chamada dos alunos."
              actionLabel="Cadastrar Turma"
              onAction={() => setIsClassModalOpen(true)}
            />
          ) : (
            <>
              {/* Select class and date */}
              <div className="p-3.5 rounded-2xl bg-[#131212] border border-[#272424] space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-[#9CA3AF] uppercase mb-1">
                    Selecionar Turma
                  </label>
                  <select
                    value={activeClass?.id || ''}
                    onChange={(e) => setSelectedClassId(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs font-bold focus:border-[#FF4A0F] focus:outline-none"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.days.join(', ')} {c.startTime})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#9CA3AF] uppercase mb-1">
                    Data da Aula
                  </label>
                  <input
                    type="date"
                    value={attendanceDate}
                    onChange={(e) => setAttendanceDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              {/* Students attendance list with 1-touch marking */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <h4 className="text-xs font-bold text-[#9CA3AF] uppercase">
                    Alunos da Turma ({classStudents.length})
                  </h4>
                  <span className="text-[11px] text-[#FF4A0F] font-semibold">1 toque para marcar</span>
                </div>

                {classStudents.length === 0 ? (
                  <p className="text-xs text-[#9CA3AF] p-4 text-center bg-[#131212] rounded-xl border border-[#272424]">
                    Nenhum aluno ativo matriculado nesta modalidade ou turma.
                  </p>
                ) : (
                  classStudents.map((student) => {
                    const currentRecord = attendance.find(
                      (a) =>
                        a.classId === activeClass?.id &&
                        a.studentId === student.id &&
                        a.date === attendanceDate
                    );

                    const isPresent = currentRecord?.status === 'PRESENTE';
                    const isAbsent = currentRecord?.status === 'FALTA';

                    // Student attendance stats
                    const studentRecords = attendance.filter((a) => a.studentId === student.id);
                    const presentTotal = studentRecords.filter((a) => a.status === 'PRESENTE').length;

                    return (
                      <div
                        key={student.id}
                        className={`p-3 rounded-xl bg-[#131212] border transition-all flex items-center justify-between gap-2 ${
                          isPresent
                            ? 'border-[#10B981]/50 bg-[#10B981]/5'
                            : isAbsent
                            ? 'border-[#EF4444]/50 bg-[#EF4444]/5'
                            : 'border-[#272424]'
                        }`}
                      >
                        <div className="flex-1">
                          <h4 className="text-xs font-bold text-white">{student.name}</h4>
                          <p className="text-[11px] text-[#9CA3AF]">
                            {student.graduation} • {presentTotal} presenças
                          </p>
                        </div>

                        {/* 1-Touch Buttons */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setStudentHistoryModal(student)}
                            className="w-9 h-9 rounded-lg border border-[#272424] text-[#9CA3AF] hover:text-white flex items-center justify-center"
                            title="Histórico de presença"
                          >
                            <History className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() =>
                              onRecordAttendance(activeClass.id, student.id, attendanceDate, 'FALTA')
                            }
                            className={`min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                              isAbsent
                                ? 'bg-[#EF4444] text-white shadow-md'
                                : 'bg-[#050505] border border-[#272424] text-[#9CA3AF] hover:text-[#EF4444]'
                            }`}
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Falta</span>
                          </button>

                          <button
                            onClick={() =>
                              onRecordAttendance(activeClass.id, student.id, attendanceDate, 'PRESENTE')
                            }
                            className={`min-h-[40px] px-3.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                              isPresent
                                ? 'bg-[#10B981] text-black shadow-md'
                                : 'bg-[#050505] border border-[#272424] text-[#9CA3AF] hover:text-[#10B981]'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Presente</span>
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}
        </div>
      )}

      {/* 3. AULAS EXPERIMENTAIS */}
      {subTab === 'experimentais' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">Interessados</h3>
            <button
              onClick={() => {
                setTrialName('');
                setTrialPhone('');
                setIsTrialModalOpen(true);
              }}
              className="min-h-[44px] px-4 rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center gap-1.5 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20"
            >
              <Plus className="w-4 h-4" />
              <span>Agendar Experimental</span>
            </button>
          </div>

          {trials.length === 0 ? (
            <EmptyState
              icon={UserPlus}
              title="Nenhuma aula experimental agendada"
              description="Cadastre pessoas interessadas em conhecer a academia para acompanhar até a matrícula."
              actionLabel="Agendar Primeiro Interessado"
              onAction={() => setIsTrialModalOpen(true)}
            />
          ) : (
            <div className="space-y-2.5">
              {trials.map((trial) => (
                <div
                  key={trial.id}
                  className="p-3.5 rounded-2xl bg-[#131212] border border-[#272424] flex items-center justify-between gap-3 shadow-md"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white">{trial.name}</h4>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          trial.status === 'CONVERTIDA'
                            ? 'bg-[#10B981]/20 text-[#10B981]'
                            : 'bg-[#F59E0B]/20 text-[#F59E0B]'
                        }`}
                      >
                        {trial.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#9CA3AF] mt-0.5">
                      {trial.modality} • Data: {trial.scheduledDate} • {trial.phone}
                    </p>

                    {trial.notes && (
                      <p className="text-[11px] text-[#6B7280] mt-1 italic">Obs: {trial.notes}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {trial.phone && (
                      <a
                        href={generateWhatsAppUrl(
                          trial.phone,
                          `Olá ${trial.name}! Confirmando sua aula experimental de ${trial.modality} na Academia UBF Team Parque Indiano no dia ${trial.scheduledDate}. Venha com roupa confortável para treino! Te esperamos no tatame! Oss!`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-9 h-9 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-center text-[#10B981] active:scale-95"
                        title="WhatsApp"
                      >
                        <Send className="w-4 h-4" />
                      </a>
                    )}

                    {trial.status !== 'CONVERTIDA' && (
                      <button
                        onClick={() => onConvertTrialToStudent(trial)}
                        className="min-h-[40px] px-3.5 rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all shadow-md shadow-[#FF4A0F]/20"
                        title="Transformar em Aluno Matriculado"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Transformar em Aluno</span>
                      </button>
                    )}

                    <button
                      onClick={() => onDeleteTrial(trial.id)}
                      className="text-[#6B7280] hover:text-[#EF4444] p-1.5"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal: Nova Turma */}
      {isClassModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-[#131212] border border-[#272424] rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#272424] mb-4">
              <h3 className="text-base font-bold text-white">Cadastrar Nova Turma</h3>
              <button onClick={() => setIsClassModalOpen(false)} className="text-[#9CA3AF] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateClass} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Nome da Turma *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Muay Thai Noite"
                  className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Modalidade</label>
                  <select
                    value={modality}
                    onChange={(e) => setModality(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  >
                    <option value="Jiu-Jitsu">Jiu-Jitsu</option>
                    <option value="Muay Thai">Muay Thai</option>
                    <option value="MMA">MMA</option>
                    <option value="Boxe">Boxe</option>
                    <option value="Funcional">Funcional</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Professor</label>
                  <input
                    type="text"
                    value={instructor}
                    onChange={(e) => setInstructor(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1.5">Dias da Semana</label>
                <div className="flex flex-wrap gap-1.5">
                  {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day) => {
                    const isSelected = days.includes(day);
                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => toggleDay(day)}
                        className={`min-w-[44px] min-h-[38px] px-2.5 rounded-lg text-xs font-bold transition-all ${
                          isSelected
                            ? 'bg-[#FF4A0F] text-white'
                            : 'bg-[#050505] text-[#9CA3AF] border border-[#272424]'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Início</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Término</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[46px] rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20 mt-4"
              >
                <Check className="w-4 h-4" />
                <span>Salvar Turma</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Nova Aula Experimental */}
      {isTrialModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-[#131212] border border-[#272424] rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#272424] mb-4">
              <h3 className="text-base font-bold text-white">Agendar Aula Experimental</h3>
              <button onClick={() => setIsTrialModalOpen(false)} className="text-[#9CA3AF] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTrial} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Nome do Interessado *</label>
                <input
                  type="text"
                  required
                  value={trialName}
                  onChange={(e) => setTrialName(e.target.value)}
                  placeholder="Nome completo"
                  className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">WhatsApp</label>
                  <input
                    type="tel"
                    value={trialPhone}
                    onChange={(e) => setTrialPhone(e.target.value)}
                    placeholder="11988887777"
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Data (dd/mm/aaaa)</label>
                  <input
                    type="text"
                    value={trialDate}
                    onChange={(e) => setTrialDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Modalidade Desejada</label>
                <select
                  value={trialModality}
                  onChange={(e) => setTrialModality(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                >
                  <option value="Jiu-Jitsu">Jiu-Jitsu</option>
                  <option value="Muay Thai">Muay Thai</option>
                  <option value="MMA">MMA</option>
                  <option value="Boxe">Boxe</option>
                  <option value="Funcional">Funcional</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Observações</label>
                <textarea
                  rows={2}
                  value={trialNotes}
                  onChange={(e) => setTrialNotes(e.target.value)}
                  placeholder="Objetivo, experiência anterior..."
                  className="w-full p-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full min-h-[46px] rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20 mt-4"
              >
                <Check className="w-4 h-4" />
                <span>Confirmar Agendamento</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Histórico de Presença do Aluno */}
      {studentHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-[#131212] border border-[#272424] rounded-2xl p-5 shadow-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#272424] mb-3">
              <div>
                <h3 className="text-sm font-bold text-white">{studentHistoryModal.name}</h3>
                <p className="text-xs text-[#FF4A0F]">{studentHistoryModal.graduation}</p>
              </div>
              <button
                onClick={() => setStudentHistoryModal(null)}
                className="text-[#9CA3AF] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase text-[#9CA3AF] mb-2">Histórico de Aulas</h4>
              {attendance.filter((a) => a.studentId === studentHistoryModal.id).length === 0 ? (
                <p className="text-xs text-[#6B7280] py-3 text-center">Nenhuma chamada registrada ainda.</p>
              ) : (
                attendance
                  .filter((a) => a.studentId === studentHistoryModal.id)
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .map((rec) => (
                    <div
                      key={rec.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-[#050505] border border-[#272424] text-xs"
                    >
                      <span className="text-white font-medium">{rec.date}</span>
                      <span
                        className={`font-bold px-2 py-0.5 rounded ${
                          rec.status === 'PRESENTE'
                            ? 'bg-[#10B981]/15 text-[#10B981]'
                            : 'bg-[#EF4444]/15 text-[#EF4444]'
                        }`}
                      >
                        {rec.status}
                      </span>
                    </div>
                  ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
