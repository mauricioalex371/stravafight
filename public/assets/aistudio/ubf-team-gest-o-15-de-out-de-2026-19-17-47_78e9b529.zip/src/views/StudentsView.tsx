import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Send, 
  Edit, 
  Trash2, 
  ShieldAlert, 
  X, 
  Check, 
  Phone,
  Calendar,
  Award,
  ChevronDown
} from 'lucide-react';
import { Student, ClassEntity } from '../types';
import { formatCurrency, generateWhatsAppUrl, generateUUID, calculateAge } from '../utils/formatters';
import { EmptyState } from '../components/EmptyState';

interface StudentsViewProps {
  students: Student[];
  classes: ClassEntity[];
  onSaveStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  students,
  classes,
  onSaveStudent,
  onDeleteStudent,
}) => {
  const [search, setSearch] = useState('');
  const [selectedModality, setSelectedModality] = useState('TODAS');
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [isMinor, setIsMinor] = useState(false);
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [modality, setModality] = useState('Jiu-Jitsu');
  const [graduation, setGraduation] = useState('Faixa Branca');
  const [classId, setClassId] = useState('');
  const [monthlyFee, setMonthlyFee] = useState('130');
  const [dueDay, setDueDay] = useState('10');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<'ATIVO' | 'TRANCADO' | 'CANCELADO'>('ATIVO');

  const modalities = ['TODAS', 'Jiu-Jitsu', 'Muay Thai', 'MMA', 'Boxe', 'Funcional'];

  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.phone.includes(search) ||
      s.graduation.toLowerCase().includes(search.toLowerCase());

    const matchesModality =
      selectedModality === 'TODAS' ||
      s.modality.toLowerCase() === selectedModality.toLowerCase();

    return matchesSearch && matchesModality;
  });

  const handleOpenAdd = () => {
    setEditingStudent(null);
    setName('');
    setPhone('');
    setBirthDate('');
    setIsMinor(false);
    setGuardianName('');
    setGuardianPhone('');
    setModality('Jiu-Jitsu');
    setGraduation('Faixa Branca');
    setClassId(classes[0]?.id || '');
    setMonthlyFee('130');
    setDueDay('10');
    setNotes('');
    setStatus('ATIVO');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (s: Student) => {
    setEditingStudent(s);
    setName(s.name);
    setPhone(s.phone);
    setBirthDate(s.birthDate);
    setIsMinor(s.isMinor);
    setGuardianName(s.guardianName || '');
    setGuardianPhone(s.guardianPhone || '');
    setModality(s.modality);
    setGraduation(s.graduation);
    setClassId(s.classId || '');
    setMonthlyFee(s.monthlyFee.toString());
    setDueDay(s.dueDay.toString());
    setNotes(s.notes || '');
    setStatus(s.status);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const student: Student = {
      id: editingStudent ? editingStudent.id : generateUUID(),
      name: name.trim(),
      phone: phone.trim(),
      birthDate: birthDate.trim(),
      isMinor,
      guardianName: isMinor ? guardianName.trim() : undefined,
      guardianPhone: isMinor ? guardianPhone.trim() : undefined,
      modality,
      graduation: graduation.trim() || 'Faixa Branca',
      classId: classId || undefined,
      monthlyFee: parseFloat(monthlyFee) || 120,
      dueDay: parseInt(dueDay, 10) || 10,
      notes: notes.trim(),
      status,
      createdAt: editingStudent ? editingStudent.createdAt : Date.now(),
    };

    onSaveStudent(student);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header bar */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Alunos</h2>
          <p className="text-xs text-[#9CA3AF]">{students.length} cadastrados no sistema</p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="min-h-[44px] px-4 rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center gap-2 hover:bg-[#ff3b00] active:scale-95 transition-all shadow-md shadow-[#FF4A0F]/20"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Aluno</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar aluno por nome, WhatsApp ou faixa..."
          className="w-full min-h-[44px] pl-10 pr-4 rounded-xl bg-[#131212] border border-[#272424] text-white text-xs placeholder:text-[#6B7280] focus:border-[#FF4A0F] focus:outline-none"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Modality Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {modalities.map((m) => {
          const isSelected = selectedModality === m;
          return (
            <button
              key={m}
              onClick={() => setSelectedModality(m)}
              className={`min-h-[36px] px-3.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-[#FF4A0F] text-white'
                  : 'bg-[#131212] text-[#9CA3AF] border border-[#272424] hover:text-white'
              }`}
            >
              {m}
            </button>
          );
        })}
      </div>

      {/* Students List or Empty State */}
      {filteredStudents.length === 0 ? (
        <EmptyState
          icon={Users}
          title={students.length === 0 ? 'Nenhum aluno cadastrado' : 'Nenhum aluno encontrado'}
          description={
            students.length === 0
              ? 'Cadastre seu primeiro aluno para começar a gerenciar turmas, presenças e mensalidades.'
              : 'Nenhum resultado corresponde à sua pesquisa ou filtro selecionado.'
          }
          actionLabel={students.length === 0 ? 'Cadastrar Primeiro Aluno' : undefined}
          onAction={students.length === 0 ? handleOpenAdd : undefined}
        />
      ) : (
        <div className="space-y-2.5">
          {filteredStudents.map((student) => {
            const age = calculateAge(student.birthDate);
            const targetClass = classes.find((c) => c.id === student.classId);

            return (
              <div
                key={student.id}
                className="p-3.5 rounded-2xl bg-[#131212] border border-[#272424] hover:border-[#FF4A0F]/40 transition-all shadow-md"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-white">{student.name}</h3>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          student.status === 'ATIVO'
                            ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30'
                            : 'bg-[#6B7280]/20 text-[#9CA3AF] border border-[#6B7280]/40'
                        }`}
                      >
                        {student.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#FF4A0F] font-semibold mt-0.5">
                      {student.graduation} • {student.modality}
                    </p>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-[#9CA3AF] mt-1.5">
                      <span>Vencimento: dia {student.dueDay}</span>
                      <span>Mensalidade: {formatCurrency(student.monthlyFee)}</span>
                      {targetClass && <span>Turma: {targetClass.name}</span>}
                      {student.birthDate && (
                        <span>Nasc: {student.birthDate} {age !== null && `(${age} anos)`}</span>
                      )}
                    </div>

                    {student.isMinor && student.guardianName && (
                      <p className="text-[11px] text-[#F59E0B] mt-1 bg-[#F59E0B]/10 p-1 rounded border border-[#F59E0B]/20 inline-block">
                        Menor de idade • Resp: {student.guardianName} ({student.guardianPhone || 's/ telefone'})
                      </p>
                    )}

                    {student.notes && (
                      <p className="text-[11px] text-[#6B7280] mt-1 italic">
                        Obs: {student.notes}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-1.5 shrink-0">
                    {student.phone && (
                      <a
                        href={generateWhatsAppUrl(
                          student.phone,
                          `Olá ${student.name}! Mensagem da academia UBF Team Parque Indiano (Mestre Uarlei Silva). Como estão seus treinos? Oss!`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-9 h-9 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-center text-[#10B981] active:scale-95 transition-all"
                        title="Conversar no WhatsApp"
                      >
                        <Send className="w-4 h-4" />
                      </a>
                    )}

                    <button
                      onClick={() => handleOpenEdit(student)}
                      className="w-9 h-9 rounded-xl bg-[#050505] border border-[#272424] flex items-center justify-center text-[#9CA3AF] hover:text-white hover:border-[#FF4A0F] active:scale-95 transition-all"
                      title="Editar Aluno"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Student Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-[#131212] border border-[#272424] rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#272424] mb-4">
              <h3 className="text-base font-bold text-white">
                {editingStudent ? 'Editar Ficha do Aluno' : 'Cadastrar Novo Aluno'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#9CA3AF] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nome do aluno"
                  className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">WhatsApp</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="11988887777"
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Nascimento (dd/mm/aaaa)</label>
                  <input
                    type="text"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    placeholder="15/10/1995"
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              {/* Menor de idade */}
              <div className="p-3 rounded-xl bg-[#050505] border border-[#272424]">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isMinor}
                    onChange={(e) => setIsMinor(e.target.checked)}
                    className="w-4 h-4 accent-[#FF4A0F] rounded"
                  />
                  <span className="text-xs font-bold text-white">Aluno Menor de Idade</span>
                </label>

                {isMinor && (
                  <div className="mt-3 space-y-2 pt-2 border-t border-[#272424]">
                    <div>
                      <label className="block text-[11px] text-[#9CA3AF] mb-1">Nome do Responsável *</label>
                      <input
                        type="text"
                        value={guardianName}
                        onChange={(e) => setGuardianName(e.target.value)}
                        placeholder="Pai, mãe ou tutor"
                        className="w-full min-h-[40px] px-3 rounded-lg bg-[#131212] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[#9CA3AF] mb-1">Telefone do Responsável</label>
                      <input
                        type="tel"
                        value={guardianPhone}
                        onChange={(e) => setGuardianPhone(e.target.value)}
                        placeholder="WhatsApp do responsável"
                        className="w-full min-h-[40px] px-3 rounded-lg bg-[#131212] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Modalidade</label>
                  <select
                    value={modality}
                    onChange={(e) => setModality(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  >
                    <option value="Jiu-Jitsu">Jiu-Jitsu</option>
                    <option value="Muay Thai">Muay Thai</option>
                    <option value="MMA">MMA</option>
                    <option value="Boxe">Boxe</option>
                    <option value="Funcional">Funcional</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Graduação / Faixa</label>
                  <input
                    type="text"
                    value={graduation}
                    onChange={(e) => setGraduation(e.target.value)}
                    placeholder="Ex: Faixa Roxa"
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              {classes.length > 0 && (
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Vincular à Turma</label>
                  <select
                    value={classId}
                    onChange={(e) => setClassId(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  >
                    <option value="">Sem turma vinculada</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.days.join(', ')} {c.startTime})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Mensalidade (R$)</label>
                  <input
                    type="number"
                    value={monthlyFee}
                    onChange={(e) => setMonthlyFee(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Dia Vencimento (1 a 31)</label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={dueDay}
                    onChange={(e) => setDueDay(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Status</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['ATIVO', 'TRANCADO', 'CANCELADO'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setStatus(st)}
                      className={`min-h-[40px] rounded-lg text-xs font-bold transition-all ${
                        status === st
                          ? 'bg-[#FF4A0F] text-white'
                          : 'bg-[#050505] text-[#9CA3AF] border border-[#272424]'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#9CA3AF] mb-1">Observações</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Lesões, objetivos ou atestado médico..."
                  className="w-full p-3 rounded-xl bg-[#050505] border border-[#272424] text-white text-xs focus:border-[#FF4A0F] focus:outline-none resize-none"
                />
              </div>

              <div className="flex gap-2.5 pt-3">
                {editingStudent && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Deseja realmente excluir o aluno ${editingStudent.name}?`)) {
                        onDeleteStudent(editingStudent.id);
                        setIsModalOpen(false);
                      }
                    }}
                    className="min-h-[44px] px-4 rounded-xl border border-[#EF4444]/40 text-[#EF4444] text-xs font-bold hover:bg-[#EF4444]/10 active:scale-95"
                  >
                    Excluir
                  </button>
                )}

                <button
                  type="submit"
                  className="flex-1 min-h-[44px] rounded-xl bg-[#FF4A0F] text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#ff3b00] active:scale-95 shadow-md shadow-[#FF4A0F]/20"
                >
                  <Check className="w-4 h-4" />
                  <span>Salvar Aluno</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
